package AdapterRecycler;

import android.app.AlertDialog;
import android.app.FragmentManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mapasgoogleactivity.MapsActivity;
import com.example.mapasgoogleactivity.R;
import com.example.mapasgoogleactivity.bancodedados;

import java.util.ArrayList;
import java.util.List;

public class AdapterRecycler extends RecyclerView.Adapter<AdapterRecycler.MyViewHolder> {
    private List<ContentValues> listEndereco;
    private FragmentManager fragmentManager = null;
    private Context context = null;

    public <p> AdapterRecycler(List<ContentValues> listEndereco, FragmentManager br, Context p) {
        this.fragmentManager = br;
        this.context = p;
        this.listEndereco = listEndereco;
    }

    public AdapterRecycler(List<ContentValues> listEndereco, androidx.fragment.app.FragmentManager supportFragmentManager, Context applicationContext) {
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.enderecolayoutadapter, parent, false);
        return new MyViewHolder(itemView);
    }

        @Override
        public void onBindViewHolder(@NonNull MyViewHolder holder, int position){
        ContentValues cv = new ContentValues();
        cv = listEndereco.get(position);

        holder.cep.setText(cv.getAsString("Cep"));
        holder.bairro.setText(cv.getAsString("bairro"));
        holder.localidade.setText(cv.getAsString("localidade"));
        holder.rua.setText(cv.getAsString("rua"));
        holder.text_id.setText(cv.getAsString("id"));
        holder.text_id.setAlpha(0);
    }

    @Override
    public int getItemCount(){return  listEndereco.size();}
    public class MyViewHolder extends RecyclerView.ViewHolder{
        private TextView cep, bairro, localidade, rua, text_id;

        public MyViewHolder(@NonNull View itemView){
            super(itemView);

            cep = itemView.findViewById(R.id.txtEnderCep);
            bairro = itemView.findViewById(R.id.txtBairro);
            localidade = itemView.findViewById(R.id.txtLocal);
            rua = itemView.findViewById(R.id.txtRua);
            text_id = itemView.findViewById(R.id.txtId);

            itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View view) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
                    builder.setTitle("Confirmar a Exclusão ");
                    builder.setMessage("Excluir com certeza esse local?");
                    builder.setCancelable(false);
                    builder.setNegativeButton("Não", null);
                    builder.setPositiveButton("Excluir", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            bancodedados db = new bancodedados(itemView.getContext());
                            int aux_lista = Integer.parseInt(text_id.getText().toString());
                            db.deletaRegistro(aux_lista);

                            Toast.makeText(itemView.getContext(),"Voce Removeu a Localização", Toast.LENGTH_LONG).show();

                            listEndereco.remove(getAdapterPosition());
                            notifyItemRemoved(getAdapterPosition());

                       }
                    });
                    builder.show();
                    return true;

                }
            });

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(itemView.getContext(), MapsActivity.class);
                    String endereco = "" + rua.getText().toString() + ", " + localidade.getText().toString() + ", " + bairro.getText().toString();

                    intent.putExtra("endereco", endereco);
                    Log.i("val", "end " + endereco);
                    Toast.makeText(itemView.getContext(), "Espere alguns segundos enquanto a localização do cep é mostrada", Toast.LENGTH_SHORT).show();
                    itemView.getContext().startActivity(intent);

                }
            });
        }
    }
}
