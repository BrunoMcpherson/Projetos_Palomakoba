package AdapterRecycler;

import android.content.Context;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;

import androidx.recyclerview.widget.RecyclerView;

class RecyclerItemClickListener implements RecyclerView.OnItemTouchListener {
    private AdapterView.OnItemClickListener bListener;
    GestureDetector bGestureDetector;

    @Override
    public boolean OnInterceptTouchEvent(RecyclerView rv, MotionEvent l) {
        View childView = rv.findChildViewUnder(l.getX(), l.getY());
        if (childView != null && bListener != null && bGestureDetector.onTouchEvent(l)) {
            bListener.onItemClick(childView, rv.getChildAdapterPosition(childView));
            return true;
        }
        return false;
    }
    @Override
     public void onTouchEvent(RecyclerView rv, MotionEvent l) {

    }
    @Override
     public  void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept){

    }
    public interface OnItemClickListener extends AdapterView.OnItemClickListener{
        public void onItemClick(View view, int position);
        public void OnLongItemClick(View view, int position);
    }

    public RecyclerItemClickListener(Context context, final RecyclerView recyclerView, OnItemClickListener listener) {
        bListener = listener;
        bGestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener(){
            @Override
            public boolean onSingleTapUp(MotionEvent l) {return true;}

            @Override
            public void onLongPress(MotionEvent l){
                View child = recyclerView.findChildViewUnder(l.getX(), l.getY());
                if (child != null && bListener != null){
                    bListener.onLongItemClick(child, recyclerView.getChildAdapterPosition(child));
                }

            }

        });
    }
}
