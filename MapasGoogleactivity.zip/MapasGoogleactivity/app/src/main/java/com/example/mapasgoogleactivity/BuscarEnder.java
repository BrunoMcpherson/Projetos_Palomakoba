package com.example.mapasgoogleactivity;

import android.content.ContentValues;
import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import AdapterRecycler.AdapterRecycler;

public class BuscarEnder extends AppCompatActivity {
    private RecyclerView recyclerView;
    bancodedados bd;
    private List<ContentValues> newArrayList;
    private List<ContentValues> listEndereco = newArrayList;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bd = new bancodedados(getApplicationContext());

        recyclerView = findViewById(R.id.recycler);
        listEndereco = bd.pesquisaTodos();
        Log.i("val", "aqui" + listEndereco.size());
        AdapterRecycler adapterRecycler = new AdapterRecycler(listEndereco, getSupportFragmentManager(), getApplicationContext());

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(adapterRecycler);
    }

}
