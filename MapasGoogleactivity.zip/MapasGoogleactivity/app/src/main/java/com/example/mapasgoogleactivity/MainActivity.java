package com.example.mapasgoogleactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.telecom.Call;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.api.Response;
import com.google.android.gms.common.api.internal.RegisterListenerMethod;
import com.example.mapasgoogleactivity.api.CEPService;
import com.example.mapasgoogleactivity.model.CEP;
import com.example.mapasgoogleactivity.model.MapsActivity;

import javax.security.auth.callback.Callback;

import AdapterRecycler.AdapterRecycler;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

     private EditText txtCepp;
     private Button btCep;
     private Button btMapa;
     private Button btSalvarEnder;
     private Button btExibirEnder;
     private TextView txtEnderCep;
     private TextView txtRua;
     private TextView txtBairro;
     private TextView txtLocal;
     private TextView txtId;
     private Retrofit retrofit;
     bancodedados bd;
     private String cep1 = "";
     private Sensor acelerometro;
     private SensorEventListener sensorEventListener;
     private RegisterListenerMethod registerListener;
     private SensorManager sensorManager;
    private Object t;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtCepp = findViewById(R.id.txtCepp);
        btCep = findViewById(R.id.btCep);
        btMapa = findViewById(R.id.btMapa);
        btSalvarEnder = findViewById(R.id.btSalvarEnder);
        btExibirEnder = findViewById(R.id.btExibirEnder);
        txtEnderCep = findViewById(R.id.txtEnderCep);
        txtRua = findViewById(R.id.txtRua);
        txtBairro=findViewById(R.id.txtBairro);
        txtLocal = findViewById(R.id.txtLocal);
        txtId = findViewById(R.id.txtId);
        String urlCep = "https://viacep.com.br/ws/";
        retrofit = new Retrofit.Builder()
                .baseurl(urlCep)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        acelerometro = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        sensorEventListener = new SensorEventListener() {
            @Override
            public void onSensorChanged(SensorEvent sensorEvent) {
                Log.i("val", "teste" +sensorEvent.values[0]);
                if(sensorEvent.values[0]>10){
                    finish();
                }
            }

            @Override
            public void onAccuracyChanged(Sensor sensor, int i) {

            }
        };

        btSalvarEnder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cep1 = txtCepp.getText().toString();
                bd = new bancodedados(getApplicationContext());

                CEPService cepServico = retrofit.create(CEPService.class);
                Call<CEP> call = cepServico.recuperarCEP(cep1);
                call.enqueue(new Callback<CEP>()){
                    @Override
                    public void onResponse(Call<CEP> call, Response<CEP> Response){
                        if(Response.isSuccessful()){

                            CEP cep = response.body();
                            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                            builder.setMessage("O cep: " + cep1 + "Esta no local: \n\n" +cep.getRua()+", "+cep.getBairro()+" - "
                            + cep.getLocal+"/" + cep.getCep());
                            builder.setCancelable(false);

                            builder.setNegativeButton("Salvar", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    ContentValues cv = new ContentValues();
                                    cv.put("Cep", cep.getCep());
                                    cv.put("Bairro", cep.getBairro());
                                    cv.put("Localidade,cep", cep.getLocalidade());
                                    cv.put("Rua", cep.getRua());

                                    Long idd = bd.inserir(cep);

                                    if (idd>0){
                                        Toast.makeText(MainActivity.this, "Salvo com sucesso", Toast.LENGTH_SHORT).show();
                                    }

                                    StringBuilder construir = new StringBuilder();
                                    construir.append(cep.getCep()).append("\n")
                                    .append(cep.getBairro()).append("\n")
                                    .append(cep.getLocalidade()).append("\n")
                                    .append(cep.Rua());

                                    Log.i("val", "vll: " +idd+" \n" +construir.toString());
                                }
                            });
                            builder.setNeutralButton("OK", null);
                            builder.show();

                            txtCepp.setText("");
                        }else{
                            Toast.makeText(MainActivity.this, "Cep nao encontrado", Toast.LENGTH_SHORT).show();
                        }
                    }
                    @Override
                     public void onFailure(Call<CEP> call, Throwable t){

                    }
                }
               btSalvarEnder.setOnClickListener(new View.OnClickListener() {
                   @Override
                   public void onClick(View view) {
                       Intent intent = new Intent(MainActivity.this, BuscarEnder.class);
                       startActivity(intent);
                   }
               });
            }
            @Override
            protected void onResume(){
                MainActivity.super.onResume();
            }

            @Override
            protected void onPause(){
                MainActivity.super.onPause();
            }
            private String recuperarCep() {
                CEPService cepService = retrofit.create(CEPService.class);
                String cep = edtCEP.getText().toString();
                Call<CEP> call = cepService.recuperarCEP(cep);
                call.enqueue(new Callback<CEP>() {
                    @Override
                    public void onResponse(Call<CEP> vall, Response<CEP> response) {
                        if (response.isSuccessful()) {
                            CEP cep = response.body();
                            endereco = cep.getRua() + " " + cep.getBairro() + "" + cep.getCep();
                            textoResultado.
                                    setText(cep.getRua() + "/" + cep.getBairro() + "/" + cep.getLocalidade());
                        }
                    }

                    @Override
                    public void onFailure(Call<CEP> call, Throwable t) {

                    }
                });
                return endereco;

            }
        });
    }
}
