package com.example.mapasgoogleactivity;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class bancodedados extends SQLiteOpenHelper {

    private SQLiteDatabase ler;
    private SQLiteDatabase escrever;

    private static final String DATABASE_NAME = "Endereçoes";
    private static final int DATABASE_VERSION = 4;
    private final String CREATE_TABLE_ENDERECO =
            "CREATE TABLE endereco(" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "bairro TEXT," +
                    "cep TEXT," +
                    "localidade TEXT," +
                    "rua TEXT); ";

    public bancodedados(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        ler = this.getReadableDatabase();
        escrever = this.getWritableDatabase();
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1){
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS endereco");
        onCreate(sqLiteDatabase);
    }

    public long inserir(CEP cep){
        ContentValues contentValues = new ContentValues();
        ContentValues.put("cep", cep.getCep());
        ContentValues.put("bairro",cep.getBairro());
        ContentValues.put("localidade",cep.getLocalidade());
        ContentValues.put("rua",cep.getRua());

        long id = escrever.insert("endereco", null, contentValues);
        return id;
    }

    public List<ContentValues> pesquisaTitulo(String titulo) {
        String sql = "SELECT * FROM endereco WHERE titulo LIKE?";
        String where[] = new String[]{"%" + titulo + "%"};
        return pesquisar(sql, where);
    }

    public List<ContentValues> pesquisaAno(int ano){
        String sql = "SELECT * FROM endereco WHERE ano LIKE";
        String where[] = null;
        return pesquisar(sql, where);
        }

    public List<ContentValues> pesquisaTodos(){
        String sql = "SELECT * FROM endereco ORDER BY id ";
        String where[] = null;
        return pesquisar(sql, where);
    }

    @SuppressLint("Range")
    private List<ContentValues> pesquisar(String sql, String where[]){
        List<ContentValues> lista = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor p = db.rawQuery(sql, where);

        if(p.moveToFirst()){
            do{
                ContentValues cv = new ContentValues();
                cv.put("cep", p.getString(p.getColumnIndex("cep")));
                cv.put("bairro", p.getString(p.getColumnIndex("bairro")));
                cv.put("localidade", p.getString(p.getColumnIndex("localidade")));
                cv.put("rua", p.getString(p.getColumnIndex("rua")));
                cv.put("id",p.getString(p.getColumnIndex("id")));
                lista.add(cv);
            }while(p.moveToNext());
        }
        return lista;
    }

    public void alteraRegistro(String cep, String bairro, String localidade, String rua, int id ){
        ContentValues valores = new ContentValues();
        String where;
        SQLiteDatabase db = this.getWritableDatabase();
        where = "id=" +id;
        valores.put("cep", cep);
        valores.put("bairro", bairro);
        valores.put("localidade", localidade);
        valores.put("rua", rua);
        db.update("endereco", valores, where, null);
        db.close();
    }

    public void deletaRegistro(int id){
        String where = "id= " + id;
        SQLiteDatabase db = this.getReadableDatabase();
        db.delete("endereco", where, null);
        db.close();
    }
}
