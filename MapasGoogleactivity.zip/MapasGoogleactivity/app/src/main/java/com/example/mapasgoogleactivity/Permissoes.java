package com.example.mapasgoogleactivity;

import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.PackageManagerCompat;

import java.util.ArrayList;
import java.util.List;

public class Permissoes {
    public static boolean validaPermissao(String[] permissoes, Activity activity, int requestCode){
        if (Build.VERSION.SDK_INT >= 23){
            List<String> listaPermissoes = new ArrayList<>(); // verifica as permissoes e verifica se esta liberado
            for (String permissao: permissoes){
                Boolean temPermissao = ContextCompat.checkSelfPermission(activity, permissao) == PackageManager.PERMISSION_GRANTED;
                if(!temPermissao) listaPermissoes.add(permissao);

            }
            if(listaPermissoes.isEmpty()) return true; // se a lista estiver vazia, nao pede permissao
            String[] newPermissoes = new String[listaPermissoes.size()];
            listaPermissoes.toArray(newPermissoes);

            ActivityCompat.requestPermissions(activity,newPermissoes,requestCode); // pede ao usuario permissao
        }
        return true;
    }
}
